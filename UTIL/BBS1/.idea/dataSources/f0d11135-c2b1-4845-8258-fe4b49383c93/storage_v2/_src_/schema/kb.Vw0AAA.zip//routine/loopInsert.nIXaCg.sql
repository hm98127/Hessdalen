create
  definer = test@localhost procedure loopInsert()
BEGIN
  DECLARE i INT DEFAULT 1;

  WHILE i <= 500 DO
  INSERT INTO board(mb_sq, subject, content, hit)
  VALUES(1, concat('제목',i), concat('내용',i), 1);
  SET i = i + 1;
  END WHILE;
END;

